/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import Logico.Conexion;
import Datos.DCitas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MASTER
 */
public class LCitas {
    //Creacion de la conexion y la variable de la misma
    private Conexion mysql=new Conexion();
    private Connection cn=mysql.Conectar();
    private String sSQL="";
    public int NúmeroCitas;
    
    DCitas d=new DCitas();
    
    //Creacion de la tabla de la interfaz
     public DefaultTableModel CargarTabla(){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [3];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select COD_HORARIO, HORA_CITA, FECHA_CITA from HORARIO";              
                  
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("HORA_CITA");
                registro[2]=rs.getString("FECHA_CITA");
               
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public DefaultTableModel mostrar(String busca){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [3];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select COD_HORARIO, HORA_CITA, FECHA_CITA from HORARIO"+
                "where COD_HORARIO=(select COD_HORARIO from CITA_MEDICA"+ 
                "where cedula=(select cedula from PACIENTE where cedula="+busca+"))";
                  
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("HORA_CITA");
                registro[2]=rs.getString("FECHA_CITA");
                              
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public boolean insertar (DCitas dci){
        NúmeroCitas=NúmeroCitas+1;
        sSQL="insert into HORARIO (HORA_CITA, FECHA_CITA)"+
                "values (?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            pst.setString(1, dci.getHoraCita());
            pst.setString(2, dci.getFechaCita());
            
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
    }
    public boolean editarHorario (DCitas dci){
        sSQL="update HORARIO set HORA_CITA=?, FECHA_CITA=? where COD_HORARIO=?"+
                "values (?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            
            pst.setString(1, dci.getHoraCita());
            pst.setString(2, dci.getFechaCita());
            pst.setInt(3, dci.getCOD_Horario() );
            
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
    }
   
    public boolean elminarHorario(DCitas dci){
        sSQL="delete from HORARIO where COD_HORARIO=?"+
                "values (?)";
        try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            
            pst.setInt(1, dci.getCOD_Horario() );
            
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
    }
  
}
